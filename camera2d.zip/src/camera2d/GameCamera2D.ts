import {Camera2D} from './Camera2D';

/**
 * 一个游戏场景的相机
 */
export class GameCamera2D extends Camera2D {
  constructor() {
    super();
  }
}
